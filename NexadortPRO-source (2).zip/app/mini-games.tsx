"use client";

import { useEffect, useRef, useState } from "react";
import { Clock, Gamepad2, Heart, Play, ShieldCheck, Star, Trophy } from "lucide-react";
import { ArcadeGame, Game, Profile, allItems, arcadeGames } from "./game-data";

type Props = {
  mode: ArcadeGame;
  profile: Profile;
  onClose: () => void;
  onFinish: (game: ArcadeGame, score: number, won: boolean, reward: number) => number;
  onCoin: (amount: number) => void;
};

type Result = { score: number; won: boolean; coins: number; earned: number };

const clamp = (n: number, a: number, b: number) => Math.max(a, Math.min(b, n));
const collide = (a: { x: number; y: number; r: number }, b: { x: number; y: number; r: number }) => Math.hypot(a.x - b.x, a.y - b.y) < a.r + b.r;
const CoinMark=({className=""}:{className?:string})=><img className={`coin-mark ${className}`} src="/nexadort-coin.webp" alt="NexadortCoin"/>;

export default function MiniGames({ mode, profile, onClose, onFinish, onCoin }: Props) {
  const canvas = useRef<HTMLCanvasElement>(null);
  const engine = useRef<{ raf: number; cleanup: () => void; input: Record<string, boolean> } | null>(null);
  const [playing, setPlaying] = useState(false);
  const [score, setScore] = useState(0);
  const [time, setTime] = useState(arcadeGames[mode].duration);
  const [health, setHealth] = useState(3);
  const [result, setResult] = useState<Result | null>(null);
  const tier = arcadeGames[mode].difficulty;
  const intensity = ({Easy:0.95, Medium:1.15, Hard:1.42, Impossible:1.75} as const)[tier];
  const coreMode:Game|null=mode==="brawl"||mode==="fortnite"||mode==="roblox"?mode:null;
  const itemId = coreMode?profile.equipped[coreMode]:"";
  const equipped = allItems.find((item) => item.id === itemId);

  useEffect(() => () => stopEngine(), []);

  function stopEngine() {
    if (engine.current) {
      cancelAnimationFrame(engine.current.raf);
      engine.current.cleanup();
      engine.current = null;
    }
  }

  function finish(finalScore: number, won: boolean) {
    stopEngine();
    setPlaying(false);
    const reward = Math.min(30, (won ? 9 : 3) + Math.floor(finalScore / 3));
    const earned = onFinish(mode, finalScore, won, reward);
    setResult({ score: finalScore, won, coins: reward, earned });
  }

  function controls() {
    const input: Record<string, boolean> = {};
    const down = (e: KeyboardEvent) => {
      input[e.key.toLowerCase()] = true;
      if (["arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(e.key.toLowerCase())) e.preventDefault();
    };
    const up = (e: KeyboardEvent) => (input[e.key.toLowerCase()] = false);
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return { input, cleanup: () => { window.removeEventListener("keydown", down); window.removeEventListener("keyup", up); } };
  }

  function start() {
    stopEngine();
    setPlaying(true); setResult(null); setScore(0);
    if (mode === "brawl") startBrawl();
    if (mode === "fortnite") startFortnite();
    if (mode === "roblox") startRoblox();
    if (mode === "stealth") startStealth();
    if (mode === "runner") startRunner();
    if (mode === "touchdown") startTouchdown();
    if (mode === "racing") startRacing();
    if (mode === "mountain") startMountain();
    if (mode === "ocean") startOcean();
    if (mode === "goalkeeper") startGoalkeeper();
    if (mode === "tysonfly") startTysonFly();
    if (mode === "rocketleague") startRocketLeague();
  }

  function startBrawl() {
    const c = canvas.current!, ctx = c.getContext("2d")!;
    const { input, cleanup } = controls();
    const maxHealth = itemId === "tank-brawler" ? 5 : 3;
    const speed = (itemId === "mythic-brawler" || itemId === "aqua-striker" ? 4.4 : 3.7) / Math.max(1,intensity*.92);
    const fireEvery = itemId === "ranger-brawler" ? 420 : itemId === "aqua-striker" ? 475 : 560;
    const state = { p: { x: 360, y: 200, r: 18 }, drones: [] as any[], bullets: [] as any[], gems: [] as any[], health: maxHealth, score: 0, start: performance.now(), lastFire: 0, lastSpawn: 0, invincible: 0, healed:false };
    setHealth(maxHealth); setTime(90);
    const spawnDrone = () => { const side = Math.floor(Math.random() * 4); state.drones.push({ x: side % 2 ? Math.random() * c.width : side === 0 ? 10 : c.width - 10, y: side % 2 ? side === 1 ? 10 : c.height - 10 : Math.random() * c.height, r: 16, hp: tier === "Impossible" ? 3 : 2 }); };
    for (let i = 0; i < Math.round(3 + intensity * 1.5); i++) spawnDrone();
    const loop = (now: number) => {
      const left = Math.max(0, 90 - Math.floor((now - state.start) / 1000)); setTime(left);
      let dx = (input.d || input.arrowright ? 1 : 0) - (input.a || input.arrowleft ? 1 : 0), dy = (input.s || input.arrowdown ? 1 : 0) - (input.w || input.arrowup ? 1 : 0);
      if (dx && dy) { dx *= .707; dy *= .707; }
      state.p.x = clamp(state.p.x + dx * speed, 20, c.width - 20); state.p.y = clamp(state.p.y + dy * speed, 20, c.height - 20);
      if (now - state.lastSpawn > 1500 / intensity && state.drones.length < Math.round(10 + intensity * 4)) { spawnDrone(); state.lastSpawn = now; }
      state.drones.forEach((d) => { const a = Math.atan2(state.p.y - d.y, state.p.x - d.x); d.x += Math.cos(a) * 1.3 * intensity; d.y += Math.sin(a) * 1.3 * intensity; });
      if (now - state.lastFire > fireEvery && state.drones.length) { const target = [...state.drones].sort((a,b)=>Math.hypot(a.x-state.p.x,a.y-state.p.y)-Math.hypot(b.x-state.p.x,b.y-state.p.y))[0]; const a=Math.atan2(target.y-state.p.y,target.x-state.p.x); state.bullets.push({x:state.p.x,y:state.p.y,r:5,vx:Math.cos(a)*7,vy:Math.sin(a)*7}); state.lastFire=now; }
      state.bullets.forEach((b)=>{b.x+=b.vx;b.y+=b.vy}); state.bullets=state.bullets.filter((b)=>b.x>-10&&b.x<c.width+10&&b.y>-10&&b.y<c.height+10);
      state.bullets.forEach((b)=>state.drones.forEach((d)=>{if(!b.dead&&collide(b,d)){b.dead=true;d.hp--;if(d.hp<=0){d.dead=true;state.gems.push({x:d.x,y:d.y,r:itemId==="mythic-brawler"?12:9})}}})); state.bullets=state.bullets.filter(b=>!b.dead);state.drones=state.drones.filter(d=>!d.dead);
      state.gems=state.gems.filter((g)=>{if(collide(state.p,g)){state.score+=itemId==="mythic-brawler"?2:1;setScore(state.score);return false}return true});
      if(itemId==="arena-medic"&&left===45&&state.health<maxHealth&&!state.healed){state.health++;state.healed=true;setHealth(state.health)}
      if(now>state.invincible&&state.drones.some(d=>collide(state.p,d))){state.health--;setHealth(state.health);state.invincible=now+1100;}
      const sky=ctx.createLinearGradient(0,0,c.width,c.height);sky.addColorStop(0,"#083b45");sky.addColorStop(1,"#116d57");ctx.fillStyle=sky;ctx.fillRect(0,0,c.width,c.height);drawArena(ctx,c);
      state.gems.forEach(g=>drawGlow(ctx,g.x,g.y,g.r,"#4de7ff"));state.bullets.forEach(b=>drawGlow(ctx,b.x,b.y,b.r,"#ffe56a"));
      state.drones.forEach(d=>drawCharacter(ctx,d.x,d.y,"/shop/tank-brawler.webp",34,50,now<state.invincible));
      drawCharacter(ctx,state.p.x,state.p.y,equipped?.image||"/shop/aqua-striker.webp",42,60,now<state.invincible);
      if(left<=0||state.health<=0)finish(state.score,state.health>0);else engine.current!.raf=requestAnimationFrame(loop);
    };
    engine.current={raf:requestAnimationFrame(loop),cleanup,input};
  }

  function startFortnite() {
    const c=canvas.current!,ctx=c.getContext("2d")!;const {input,cleanup}=controls();
    const slowDamage=itemId==="storm-guardian"||itemId==="sky-guardian",bonus=itemId==="neon-striker"?2:1,magnet=itemId==="forest-scout";let shield=itemId==="cosmic-champion"||itemId==="sky-guardian"?1:0;
    const state={p:{x:360,y:200,r:17},loot:[] as any[],health:3,score:0,start:performance.now(),lastDamage:0,zone:{x:360,y:200,r:185},nextZone:0};setHealth(3);setTime(105);
    const spawnLoot=()=>state.loot.push({x:40+Math.random()*(c.width-80),y:40+Math.random()*(c.height-80),r:10});for(let i=0;i<8;i++)spawnLoot();
    const loop=(now:number)=>{const elapsed=(now-state.start)/1000,left=Math.max(0,105-Math.floor(elapsed));setTime(left);const speed=3.9;let dx=(input.d||input.arrowright?1:0)-(input.a||input.arrowleft?1:0),dy=(input.s||input.arrowdown?1:0)-(input.w||input.arrowup?1:0);if(dx&&dy){dx*=.707;dy*=.707}state.p.x=clamp(state.p.x+dx*speed,18,c.width-18);state.p.y=clamp(state.p.y+dy*speed,18,c.height-18);
      state.zone.r=Math.max(42,185-elapsed*(1.3*intensity));if(elapsed>state.nextZone){state.zone.x=clamp(state.zone.x+(Math.random()-.5)*105,150,c.width-150);state.zone.y=clamp(state.zone.y+(Math.random()-.5)*75,110,c.height-110);state.nextZone=elapsed+Math.max(4,9/intensity);}
      if(magnet)state.loot.forEach(l=>{const d=Math.hypot(state.p.x-l.x,state.p.y-l.y);if(d<90){l.x+=(state.p.x-l.x)*.035;l.y+=(state.p.y-l.y)*.035}});state.loot=state.loot.filter(l=>{if(collide(state.p,l)){state.score+=bonus;setScore(state.score);spawnLoot();return false}return true});
      const outside=Math.hypot(state.p.x-state.zone.x,state.p.y-state.zone.y)>state.zone.r-state.p.r;if(outside&&now-state.lastDamage>(slowDamage?1750:1150)/intensity){if(shield)shield=0;else{state.health--;setHealth(state.health)}state.lastDamage=now;}
      const storm=ctx.createLinearGradient(0,0,c.width,c.height);storm.addColorStop(0,"#143c4a");storm.addColorStop(1,"#17846d");ctx.fillStyle="#31536b";ctx.fillRect(0,0,c.width,c.height);ctx.fillStyle=storm;ctx.beginPath();ctx.arc(state.zone.x,state.zone.y,state.zone.r,0,Math.PI*2);ctx.fill();ctx.strokeStyle="#71ffd2";ctx.lineWidth=5;ctx.stroke();drawLandscape(ctx,c);state.loot.forEach(l=>{ctx.fillStyle="#d9ff71";ctx.beginPath();ctx.roundRect(l.x-10,l.y-8,20,16,4);ctx.fill();ctx.strokeStyle="#fff";ctx.stroke()});drawCharacter(ctx,state.p.x,state.p.y,equipped?.image||"/shop/forest-scout.webp",42,60,false);ctx.fillStyle="#fff";ctx.font="bold 13px Arial";ctx.fillText(outside?"IN THE STORM!":"SAFE ZONE",18,24);if(shield)ctx.fillText("SHIELD READY",18,43);
      if(left<=0||state.health<=0)finish(state.score,state.health>0);else engine.current!.raf=requestAnimationFrame(loop)};
    engine.current={raf:requestAnimationFrame(loop),cleanup,input};
  }

  function startRoblox() {
    const c=canvas.current!,ctx=c.getContext("2d")!;const {input,cleanup}=controls();const doubleJump=itemId==="block-adventurer"||itemId==="future-explorer",scoreBoost=itemId==="code-master"?2:1,speed=itemId==="galaxy-creator"||itemId==="future-explorer"?4.3:3.8,jump=itemId==="galaxy-creator"||itemId==="future-explorer"?-11.3:-9.8,magnet=itemId==="metro-builder";
    const platforms=[{x:0,y:365,w:135,h:35},{x:170,y:320,w:100,h:18},{x:305,y:270,w:95,h:18},{x:430,y:325,w:90,h:18},{x:555,y:255,w:85,h:18},{x:670,y:205,w:100,h:18},{x:805,y:270,w:105,h:18},{x:950,y:205,w:90,h:18},{x:1075,y:145,w:130,h:18},{x:1245,y:220,w:140,h:18},{x:1425,y:160,w:150,h:18},{x:1620,y:245,w:100,h:18},{x:1765,y:190,w:115,h:18},{x:1925,y:120,w:160,h:18}];const checks=[230,360,600,850,1120,1500,1680,1830,2020];const state={p:{x:45,y:320,r:15,vx:0,vy:0,on:false,jumps:0},camera:0,score:0,start:performance.now(),health:3,hit:0,claimed:new Set<number>()};setHealth(3);setTime(135);
    const loop=(now:number)=>{const left=Math.max(0,135-Math.floor((now-state.start)/1000));setTime(left);state.p.vx=((input.d||input.arrowright?1:0)-(input.a||input.arrowleft?1:0))*speed;if((input.w||input.arrowup||input[" "])&&state.p.on){state.p.vy=jump;state.p.on=false;state.p.jumps=1;input.w=input.arrowup=input[" "]=false}else if(doubleJump&&(input.w||input.arrowup||input[" "])&&state.p.jumps===1){state.p.vy=jump*.9;state.p.jumps=2;input.w=input.arrowup=input[" "]=false}state.p.vy+=.5;state.p.x+=state.p.vx;state.p.y+=state.p.vy;state.p.on=false;
      platforms.forEach(p=>{if(state.p.x+state.p.r>p.x&&state.p.x-state.p.r<p.x+p.w&&state.p.y+state.p.r>=p.y&&state.p.y+state.p.r<=p.y+14&&state.p.vy>=0){state.p.y=p.y-state.p.r;state.p.vy=0;state.p.on=true;state.p.jumps=0}});
      checks.forEach((x,i)=>{if(!state.claimed.has(i)&&Math.abs(state.p.x-x)<(magnet?55:22)){state.claimed.add(i);state.score+=scoreBoost;setScore(state.score)}});if(state.p.y>440){state.health--;setHealth(state.health);state.p.x=Math.max(35,state.p.x-120);state.p.y=100;state.p.vy=0}state.camera=clamp(state.p.x-180,0,1420);
      const city=ctx.createLinearGradient(0,0,0,c.height);city.addColorStop(0,"#6be0d3");city.addColorStop(1,"#d8fff0");ctx.fillStyle=city;ctx.fillRect(0,0,c.width,c.height);drawSkyline(ctx,state.camera);ctx.save();ctx.translate(-state.camera,0);platforms.forEach((p,i)=>{ctx.fillStyle=i%2?"#24546a":"#1c8066";ctx.fillRect(p.x,p.y,p.w,p.h);ctx.fillStyle="#dff9ef";ctx.fillRect(p.x,p.y,p.w,4)});checks.forEach((x,i)=>{if(!state.claimed.has(i)){drawGlow(ctx,x,220-(i%3)*35,10,"#d9ff62")}});ctx.fillStyle="#15bb91";ctx.fillRect(2020,50,55,80);ctx.fillStyle="#fff";ctx.font="bold 12px Arial";ctx.fillText("GOAL",2027,43);drawCharacter(ctx,state.p.x,state.p.y,equipped?.image||"/shop/city-runner.webp",42,62,false);ctx.restore();
      const won=state.p.x>2025;if(won||left<=0||state.health<=0)finish(state.score,won);else engine.current!.raf=requestAnimationFrame(loop)};engine.current={raf:requestAnimationFrame(loop),cleanup,input};
  }

  function startStealth(){
    const c=canvas.current!,ctx=c.getContext("2d")!;const {input,cleanup}=controls();const cards=[{x:130,y:90,r:11},{x:360,y:310,r:11},{x:585,y:120,r:11},{x:610,y:345,r:11}];
    const state={p:{x:45,y:350,r:16},guards:[{x:210,y:90,r:18,vx:1.55,vy:0},{x:430,y:210,r:18,vx:0,vy:1.45},{x:590,y:320,r:18,vx:-1.6,vy:0},{x:315,y:75,r:18,vx:1.25,vy:.8}],cards,score:0,health:3,start:performance.now(),hit:0};setHealth(3);setTime(105);
    const loop=(now:number)=>{const left=Math.max(0,105-Math.floor((now-state.start)/1000));setTime(left);let dx=(input.d||input.arrowright?1:0)-(input.a||input.arrowleft?1:0),dy=(input.s||input.arrowdown?1:0)-(input.w||input.arrowup?1:0);if(dx&&dy){dx*=.707;dy*=.707}state.p.x=clamp(state.p.x+dx*3.25,18,c.width-18);state.p.y=clamp(state.p.y+dy*3.25,18,c.height-18);state.guards.forEach(g=>{g.x+=g.vx;g.y+=g.vy;if(g.x<90||g.x>650)g.vx*=-1;if(g.y<70||g.y>345)g.vy*=-1});state.cards=state.cards.filter(card=>{if(collide(state.p,card)){state.score++;setScore(state.score);return false}return true});if(now-state.hit>1300&&state.guards.some(g=>Math.hypot(g.x-state.p.x,g.y-state.p.y)<48)){state.health--;setHealth(state.health);state.hit=now;state.p.x=45;state.p.y=350}const bg=ctx.createLinearGradient(0,0,c.width,c.height);bg.addColorStop(0,"#071f2c");bg.addColorStop(1,"#0d5f5a");ctx.fillStyle=bg;ctx.fillRect(0,0,c.width,c.height);drawFacility(ctx,c);state.cards.forEach(card=>{ctx.fillStyle="#7dffd1";ctx.beginPath();ctx.roundRect(card.x-12,card.y-8,24,16,4);ctx.fill()});state.guards.forEach(g=>drawCharacter(ctx,g.x,g.y,"/shop/forest-scout.webp",38,56,false));drawCharacter(ctx,state.p.x,state.p.y,"/shop/stealth-agent.webp",42,62,now-state.hit<400);ctx.fillStyle=state.cards.length?"#355968":"#63f3bd";ctx.fillRect(665,22,38,65);ctx.fillStyle="#fff";ctx.font="bold 11px Arial";ctx.fillText(state.cards.length?"LOCKED":"EXIT",666,17);const won=!state.cards.length&&state.p.x>650&&state.p.y<110;if(won||left<=0||state.health<=0)finish(state.score,won);else engine.current!.raf=requestAnimationFrame(loop)};engine.current={raf:requestAnimationFrame(loop),cleanup,input};
  }

  function startRunner(){
    const c=canvas.current!,ctx=c.getContext("2d")!;const {input,cleanup}=controls();const state={p:{x:115,y:315,r:18,vy:0,on:true},obstacles:[] as any[],tokens:[] as any[],health:3,score:0,start:performance.now(),spawn:0,hit:0};setHealth(3);setTime(90);
    const loop=(now:number)=>{const left=Math.max(0,90-Math.floor((now-state.start)/1000));setTime(left);if((input.w||input.arrowup||input[" "])&&state.p.on){state.p.vy=-11;state.p.on=false;input.w=input.arrowup=input[" "]=false}state.p.vy+=.55;state.p.y+=state.p.vy;if(state.p.y>=315){state.p.y=315;state.p.vy=0;state.p.on=true}if(now-state.spawn>820/intensity){if(Math.random()>.28)state.obstacles.push({x:760,y:329,r:20,w:26,h:50});else state.tokens.push({x:760,y:235+Math.random()*65,r:10});state.spawn=now}state.obstacles.forEach(o=>o.x-=6.2*intensity);state.tokens.forEach(t=>t.x-=6.2*intensity);state.tokens=state.tokens.filter(t=>{if(Math.hypot(t.x-state.p.x,t.y-state.p.y)<30){state.score++;setScore(state.score);return false}return t.x>-20});if(now-state.hit>1100/intensity&&state.obstacles.some(o=>Math.abs(o.x-state.p.x)<25&&state.p.y+25>o.y-o.h)){state.health--;setHealth(state.health);state.hit=now}state.obstacles=state.obstacles.filter(o=>o.x>-30);const sky=ctx.createLinearGradient(0,0,0,400);sky.addColorStop(0,"#5fe0d0");sky.addColorStop(1,"#d8ffef");ctx.fillStyle=sky;ctx.fillRect(0,0,c.width,c.height);drawMovingCity(ctx,now);ctx.fillStyle="#173f47";ctx.fillRect(0,350,c.width,50);ctx.fillStyle="#7affba";ctx.fillRect(0,347,c.width,3);state.obstacles.forEach(o=>{ctx.fillStyle="#14313b";ctx.beginPath();ctx.roundRect(o.x-o.w/2,o.y-o.h,o.w,o.h,4);ctx.fill()});state.tokens.forEach(t=>drawGlow(ctx,t.x,t.y,t.r,"#dfff62"));drawCharacter(ctx,state.p.x,state.p.y,"/shop/city-runner.webp",48,70,now-state.hit<350);if(left<=0||state.health<=0)finish(state.score,state.health>0);else engine.current!.raf=requestAnimationFrame(loop)};engine.current={raf:requestAnimationFrame(loop),cleanup,input};
  }

  function startTouchdown(){
    const c=canvas.current!,ctx=c.getContext("2d")!;const {input,cleanup}=controls();const state={p:{x:360,y:345,r:18},defenders:[] as any[],health:3,score:0,start:performance.now(),spawn:0,hit:0};setHealth(3);setTime(90);const spawn=()=>state.defenders.push({x:70+Math.random()*580,y:40+Math.random()*160,r:18,vx:(Math.random()-.5)*2,vy:1.3+Math.random()*.9});for(let i=0;i<6;i++)spawn();
    const loop=(now:number)=>{const left=Math.max(0,90-Math.floor((now-state.start)/1000));setTime(left);let dx=(input.d||input.arrowright?1:0)-(input.a||input.arrowleft?1:0),dy=(input.s||input.arrowdown?1:0)-(input.w||input.arrowup?1:0);if(dx&&dy){dx*=.707;dy*=.707}state.p.x=clamp(state.p.x+dx*4,25,c.width-25);state.p.y=clamp(state.p.y+dy*4,20,c.height-20);state.defenders.forEach(d=>{const a=Math.atan2(state.p.y-d.y,state.p.x-d.x);d.x+=Math.cos(a)*1.28+d.vx*.2;d.y+=Math.sin(a)*1.28});if(now-state.spawn>2600&&state.defenders.length<11){spawn();state.spawn=now}if(now-state.hit>1200&&state.defenders.some(d=>Math.hypot(d.x-state.p.x,d.y-state.p.y)<34)){state.health--;setHealth(state.health);state.hit=now;state.p.x=360;state.p.y=345}if(state.p.y<35){state.score++;setScore(state.score);state.p.x=360;state.p.y=345;state.defenders.forEach(d=>{d.y=Math.max(70,d.y-50)})}ctx.fillStyle="#0b7c5c";ctx.fillRect(0,0,c.width,c.height);drawField(ctx,c);state.defenders.forEach((d,i)=>drawCharacter(ctx,d.x,d.y,i%2?"/shop/aqua-striker.webp":"/shop/tank-brawler.webp",38,55,false));drawCharacter(ctx,state.p.x,state.p.y,"/shop/touchdown-star.webp",45,65,now-state.hit<350);if(left<=0||state.health<=0)finish(state.score,state.score>=5);else engine.current!.raf=requestAnimationFrame(loop)};engine.current={raf:requestAnimationFrame(loop),cleanup,input};
  }

  function startRacing(){
    const c=canvas.current!,ctx=c.getContext("2d")!;const {input,cleanup}=controls();const state={p:{x:360,y:325,r:18},traffic:[] as any[],health:3,score:0,start:performance.now(),spawn:0,hit:0};setHealth(3);setTime(100);
    const loop=(now:number)=>{const left=Math.max(0,100-Math.floor((now-state.start)/1000));setTime(left);const move=(input.d||input.arrowright?1:0)-(input.a||input.arrowleft?1:0);state.p.x=clamp(state.p.x+move*5.2,215,505);if(now-state.spawn>720){state.traffic.push({x:[250,360,470][Math.floor(Math.random()*3)],y:-45,r:18,speed:5.8+Math.random()*2.4,passed:false});state.spawn=now}state.traffic.forEach(o=>{o.y+=o.speed;if(!o.passed&&o.y>state.p.y+55){o.passed=true;state.score++;setScore(state.score)}});if(now-state.hit>1050&&state.traffic.some(o=>Math.abs(o.x-state.p.x)<38&&Math.abs(o.y-state.p.y)<55)){state.health--;setHealth(state.health);state.hit=now}state.traffic=state.traffic.filter(o=>o.y<c.height+80);drawRoad(ctx,c,now);state.traffic.forEach((o,i)=>drawCharacter(ctx,o.x,o.y,i%2?"/shop/city-runner.webp":"/shop/touchdown-star.webp",48,68,false));drawCharacter(ctx,state.p.x,state.p.y,"/shop/neon-driver.webp",55,78,now-state.hit<380);if(left<=0||state.health<=0)finish(state.score,state.health>0&&state.score>=30);else engine.current!.raf=requestAnimationFrame(loop)};engine.current={raf:requestAnimationFrame(loop),cleanup,input};
  }

  function startMountain(){
    const c=canvas.current!,ctx=c.getContext("2d")!;const {input,cleanup}=controls();const packs=[{x:160,y:315,r:11},{x:350,y:220,r:11},{x:555,y:125,r:11}];const rocks=[{x:250,y:285,r:27},{x:430,y:170,r:30},{x:510,y:320,r:25},{x:630,y:230,r:28}];const state={p:{x:50,y:350,r:17},packs,health:3,score:0,start:performance.now(),hit:0};setHealth(3);setTime(120);
    const loop=(now:number)=>{const left=Math.max(0,120-Math.floor((now-state.start)/1000));setTime(left);let dx=(input.d||input.arrowright?1:0)-(input.a||input.arrowleft?1:0),dy=(input.s||input.arrowdown?1:0)-(input.w||input.arrowup?1:0);if(dx&&dy){dx*=.707;dy*=.707}state.p.x=clamp(state.p.x+dx*3,18,c.width-18);state.p.y=clamp(state.p.y+dy*3,18,c.height-18);state.packs=state.packs.filter(pack=>{if(collide(state.p,pack)){state.score++;setScore(state.score);return false}return true});if(now-state.hit>1200&&rocks.some(r=>collide(state.p,r))){state.health--;setHealth(state.health);state.hit=now;state.p.x=Math.max(45,state.p.x-70)}drawMountain(ctx,c);rocks.forEach(r=>drawRock(ctx,r.x,r.y,r.r));state.packs.forEach(p=>{ctx.fillStyle="#f5f1dc";ctx.beginPath();ctx.roundRect(p.x-12,p.y-10,24,20,5);ctx.fill();ctx.fillStyle="#11aa85";ctx.fillRect(p.x-3,p.y-7,6,14);ctx.fillRect(p.x-7,p.y-3,14,6)});ctx.fillStyle=state.packs.length?"#789c9b":"#ffd85d";ctx.beginPath();ctx.arc(670,65,24,0,Math.PI*2);ctx.fill();drawCharacter(ctx,state.p.x,state.p.y,"/shop/mountain-rescuer.webp",48,70,now-state.hit<350);const won=!state.packs.length&&Math.hypot(state.p.x-670,state.p.y-65)<40;if(won||left<=0||state.health<=0)finish(state.score,won);else engine.current!.raf=requestAnimationFrame(loop)};engine.current={raf:requestAnimationFrame(loop),cleanup,input};
  }

  function startOcean(){
    const c=canvas.current!,ctx=c.getContext("2d")!;const {input,cleanup}=controls();const buoys=Array.from({length:7},(_,i)=>({x:120+(i%4)*155,y:70+Math.floor(i/4)*220,r:12}));const state={p:{x:50,y:200,r:17},buoys,hazards:Array.from({length:6},()=>({x:160+Math.random()*520,y:40+Math.random()*320,r:22,vx:(Math.random()-.5)*2,vy:(Math.random()-.5)*1.4})),health:3,score:0,start:performance.now(),hit:0};setHealth(3);setTime(105);
    const loop=(now:number)=>{const left=Math.max(0,105-Math.floor((now-state.start)/1000));setTime(left);let dx=(input.d||input.arrowright?1:0)-(input.a||input.arrowleft?1:0),dy=(input.s||input.arrowdown?1:0)-(input.w||input.arrowup?1:0);const current=Math.sin(now/650)*.7;state.p.x=clamp(state.p.x+dx*3.4+current,18,c.width-18);state.p.y=clamp(state.p.y+dy*3.4,18,c.height-18);state.hazards.forEach(h=>{h.x+=h.vx;h.y+=h.vy;if(h.x<80||h.x>690)h.vx*=-1;if(h.y<30||h.y>370)h.vy*=-1});state.buoys=state.buoys.filter(b=>{if(collide(state.p,b)){state.score++;setScore(state.score);return false}return true});if(now-state.hit>1150&&state.hazards.some(h=>collide(state.p,h))){state.health--;setHealth(state.health);state.hit=now}drawOcean(ctx,c,now);state.hazards.forEach(h=>{ctx.fillStyle="#263d44";ctx.beginPath();ctx.ellipse(h.x,h.y,h.r,h.r*.55,0,0,Math.PI*2);ctx.fill()});state.buoys.forEach(b=>{ctx.fillStyle="#ffcf4d";ctx.beginPath();ctx.arc(b.x,b.y,b.r,0,Math.PI*2);ctx.fill();ctx.strokeStyle="#fff";ctx.lineWidth=4;ctx.stroke()});drawCharacter(ctx,state.p.x,state.p.y,"/shop/ocean-rescuer.webp",48,70,now-state.hit<350);const won=!state.buoys.length&&state.p.x<75;if(won||left<=0||state.health<=0)finish(state.score,won);else engine.current!.raf=requestAnimationFrame(loop)};engine.current={raf:requestAnimationFrame(loop),cleanup,input};
  }

  function startGoalkeeper(){
    const c=canvas.current!,ctx=c.getContext("2d")!;const {input,cleanup}=controls();const state={p:{x:360,y:335,r:24},balls:[] as any[],health:5,score:0,start:performance.now(),spawn:0};setHealth(5);setTime(90);
    const loop=(now:number)=>{const left=Math.max(0,90-Math.floor((now-state.start)/1000));setTime(left);const dx=(input.d||input.arrowright?1:0)-(input.a||input.arrowleft?1:0);state.p.x=clamp(state.p.x+dx*5.7,120,600);if(now-state.spawn>620){const x=100+Math.random()*520;state.balls.push({x,y:-15,r:11,vx:(360-x)*.004+(Math.random()-.5)*.8,vy:5+Math.random()*2.3,saved:false});state.spawn=now}state.balls.forEach(b=>{b.x+=b.vx;b.y+=b.vy;if(!b.saved&&Math.hypot(b.x-state.p.x,b.y-state.p.y)<43){b.saved=true;state.score++;setScore(state.score)}if(!b.saved&&b.y>375){b.saved=true;state.health--;setHealth(state.health)}});state.balls=state.balls.filter(b=>b.y<430&&!b.saved);drawGoal(ctx,c);state.balls.forEach(b=>{ctx.fillStyle="#fff";ctx.strokeStyle="#152f35";ctx.lineWidth=3;ctx.beginPath();ctx.arc(b.x,b.y,b.r,0,Math.PI*2);ctx.fill();ctx.stroke()});drawCharacter(ctx,state.p.x,state.p.y,"/shop/goalkeeper.webp",58,78,false);if(left<=0||state.health<=0)finish(state.score,state.health>0&&state.score>=18);else engine.current!.raf=requestAnimationFrame(loop)};engine.current={raf:requestAnimationFrame(loop),cleanup,input};
  }

  function startRocketLeague(){
    const c=canvas.current!,ctx=c.getContext("2d")!;const {input,cleanup}=controls();
    const state={player:{x:150,y:200,r:20},bot:{x:570,y:200,r:20},ball:{x:360,y:200,r:12,vx:0,vy:0},playerGoals:0,botGoals:0,start:performance.now(),lastGoal:0};setHealth(5);setTime(180);
    const resetBall=(toward:number)=>{state.ball.x=360;state.ball.y=200;state.ball.vx=toward*1.2;state.ball.vy=(Math.random()-.5)*1.2;state.player.x=150;state.player.y=200;state.bot.x=570;state.bot.y=200};
    const loop=(now:number)=>{
      const left=Math.max(0,180-Math.floor((now-state.start)/1000));setTime(left);let dx=(input.d||input.arrowright?1:0)-(input.a||input.arrowleft?1:0),dy=(input.s||input.arrowdown?1:0)-(input.w||input.arrowup?1:0);if(dx&&dy){dx*=.707;dy*=.707}
      state.player.x=clamp(state.player.x+dx*4.5,55,665);state.player.y=clamp(state.player.y+dy*4.5,72,328);
      const ba=Math.atan2(state.ball.y-state.bot.y,state.ball.x-state.bot.x);state.bot.x=clamp(state.bot.x+Math.cos(ba)*2.8*intensity,55,665);state.bot.y=clamp(state.bot.y+Math.sin(ba)*2.8*intensity,72,328);
      const kick=(car:{x:number;y:number},power:number)=>{const d=Math.hypot(state.ball.x-car.x,state.ball.y-car.y);if(d<42){const a=Math.atan2(state.ball.y-car.y,state.ball.x-car.x);state.ball.vx=Math.cos(a)*power;state.ball.vy=Math.sin(a)*power}};
      if(Math.hypot(state.ball.x-state.player.x,state.ball.y-state.player.y)<40)kick(state.player,8);if(Math.hypot(state.ball.x-state.bot.x,state.ball.y-state.bot.y)<40)kick(state.bot,7.2);
      state.ball.x+=state.ball.vx;state.ball.y+=state.ball.vy;state.ball.vx*=.985;state.ball.vy*=.985;if(state.ball.y<58||state.ball.y>342){state.ball.y=clamp(state.ball.y,58,342);state.ball.vy*=-.9}
      if(now-state.lastGoal>900&&state.ball.x<25){state.botGoals++;state.lastGoal=now;resetBall(1)}if(now-state.lastGoal>900&&state.ball.x>695){state.playerGoals++;state.lastGoal=now;setScore(state.playerGoals);onCoin(1);resetBall(-1)}
      const sky=ctx.createLinearGradient(0,0,0,c.height);sky.addColorStop(0,"#153c55");sky.addColorStop(1,"#0a9a6c");ctx.fillStyle=sky;ctx.fillRect(0,0,c.width,c.height);ctx.fillStyle="#22a96b";ctx.beginPath();ctx.moveTo(55,58);ctx.lineTo(665,58);ctx.lineTo(710,342);ctx.lineTo(10,342);ctx.closePath();ctx.fill();ctx.strokeStyle="#d7fff0";ctx.lineWidth=3;ctx.stroke();ctx.strokeRect(350,58,20,284);ctx.beginPath();ctx.arc(360,200,52,0,Math.PI*2);ctx.stroke();ctx.fillStyle="#e8fff4";ctx.fillRect(8,150,38,100);ctx.fillRect(674,150,38,100);ctx.fillStyle="#143f4f";ctx.font="bold 22px Arial";ctx.fillText(`${state.playerGoals}  -  ${state.botGoals}`,318,38);ctx.font="bold 12px Arial";ctx.fillText("YOU",260,38);ctx.fillText("AI",450,38);ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(state.ball.x,state.ball.y,state.ball.r,0,Math.PI*2);ctx.fill();ctx.strokeStyle="#193a44";ctx.stroke();drawCharacter(ctx,state.player.x,state.player.y,"/shop/neon-driver.webp",48,34,false);drawCharacter(ctx,state.bot.x,state.bot.y,"/shop/city-runner.webp",48,34,false);
      if(state.playerGoals>=5||state.botGoals>=5||left<=0)finish(state.playerGoals,state.playerGoals>=5);else engine.current!.raf=requestAnimationFrame(loop)
    };engine.current={raf:requestAnimationFrame(loop),cleanup,input};
  }

  function startTysonFly(){
    const c=canvas.current!,ctx=c.getContext("2d")!;const {input,cleanup}=controls();
    const pipes:any[]=[];const state={y:200,vy:0,score:0,start:performance.now(),lastPipe:0,dead:false};setHealth(1);setTime(75);
    const loop=(now:number)=>{
      const left=Math.max(0,75-Math.floor((now-state.start)/1000));setTime(left);
      if(input.w||input.arrowup||input[" "]){state.vy=-8.6;input.w=input.arrowup=input[" "]=false}state.vy+=.42;state.y+=state.vy;
      if(now-state.lastPipe>1450){const gap=145+Math.random()*45,top=35+Math.random()*150;pipes.push({x:c.width+20,top,bottom:top+gap,passed:false});state.lastPipe=now}
      pipes.forEach(p=>{p.x-=3.4*intensity;if(!p.passed&&p.x<125){p.passed=true;state.score++;setScore(state.score);onCoin(1)}});
      const hit=state.y<18||state.y>c.height-28||pipes.some(p=>p.x<150&&p.x+58>100&&(state.y<p.top||state.y>p.bottom));
      const bg=ctx.createLinearGradient(0,0,0,c.height);bg.addColorStop(0,"#7ae7d5");bg.addColorStop(1,"#159565");ctx.fillStyle=bg;ctx.fillRect(0,0,c.width,c.height);ctx.fillStyle="#8be36f";for(let x=0;x<c.width;x+=24){ctx.fillRect(x,85+(x%6)*12,2,18)}ctx.fillStyle="#8b5a36";ctx.fillRect(28,62,110,55);ctx.fillStyle="#d89b59";ctx.beginPath();ctx.moveTo(20,62);ctx.lineTo(83,28);ctx.lineTo(146,62);ctx.closePath();ctx.fill();pipes.forEach(p=>{ctx.fillStyle="#217f56";ctx.fillRect(p.x,0,58,p.top);ctx.fillRect(p.x,p.bottom,58,c.height-p.bottom);ctx.fillStyle="#45c47c";ctx.fillRect(p.x-6,p.top-14,70,14);ctx.fillRect(p.x-6,p.bottom,70,14)});const flap=Math.sin(now/90)*.12;ctx.save();ctx.translate(100,state.y);ctx.rotate(flap);drawCharacter(ctx,0,0,"/boxer-dog-skin.png",52,64,false);ctx.restore();ctx.fillStyle="#073b43";ctx.font="bold 14px Arial";ctx.fillText(`PIPES PASSED: ${state.score}`,18,24);ctx.fillText("SPACE / ↑ = FLAP",18,46);if(hit||left<=0)finish(state.score,state.score>=12&&!hit);else engine.current!.raf=requestAnimationFrame(loop)
    };engine.current={raf:requestAnimationFrame(loop),cleanup,input};
  }

  function press(key: string, value: boolean) { if (engine.current) engine.current.input[key] = value; }
  const title=arcadeGames[mode].short;
  const touch=(key:string,label:string)=><button onPointerDown={()=>press(key,true)} onPointerUp={()=>press(key,false)} onPointerCancel={()=>press(key,false)} onPointerLeave={()=>press(key,false)}>{label}</button>;
  const instructions:Record<ArcadeGame,string>={brawl:"Move: WASD / arrows · Your hero auto-fires",fortnite:"Move: WASD / arrows · Follow the safe zone",roblox:"Move: A/D or arrows · Jump: W, ↑ or Space",stealth:"Move quietly with WASD / arrows · Collect 4 cards",runner:"Move: A/D or arrows · Jump: W, ↑ or Space",touchdown:"Carry the ball with WASD / arrows · Score 5 times",racing:"Steer: A/D or left/right arrows · Avoid traffic",mountain:"Move: WASD / arrows · Collect 3 medical packs",ocean:"Swim: WASD / arrows · Recover 7 buoys and return",goalkeeper:"Move: A/D or left/right arrows · Block the shots",tysonfly:"Space / ↑ to flap Tyson through the pipes",rocketleague:"Drive: WASD / arrows · Score 5 goals before the AI"};
  const horizontalOnly=["racing","goalkeeper"].includes(mode),jumpOnly=["roblox","runner","tysonfly"].includes(mode);
  return <div className="modal-backdrop"><div className="game-modal">
    <button className="close-modal" onClick={onClose}>×</button>
    <div className="game-title"><span className={`game-chip ${arcadeGames[mode].color}`}>{arcadeGames[mode].name} · {arcadeGames[mode].difficulty}</span><h2>{title}</h2><p>{arcadeGames[mode].description}</p></div>
    <div className="game-stats"><span><Star/> {score}</span><span><Heart/> {health}</span><span><Clock/> {time}s</span>{equipped&&<span className="loadout"><img src={equipped.image} alt=""/> {equipped.name}</span>}</div>
    <canvas ref={canvas} width={720} height={400}/>
    <div className="game-controls"><span>{instructions[mode]}</span><div className="touch-pad">{touch("arrowleft","←")}{!horizontalOnly&&touch("arrowup","↑")}{touch("arrowright","→")}{!horizontalOnly&&!jumpOnly&&touch("arrowdown","↓")}</div></div>
    {!playing&&<div className="game-overlay">{!result?<><Gamepad2/><h3>Ready for a harder mission?</h3><p>{equipped?`${equipped.name} is equipped: ${equipped.perk}`:`This ${arcadeGames[mode].duration}-second ${arcadeGames[mode].difficulty.toLowerCase()} mission uses a realistic character.`}</p><button className="primary" onClick={start}><Play/> Start mission</button></>:<><Trophy/><h3>{result.won?"Mission complete!":"Mission ended"}</h3><p className="coin-earned"><CoinMark/> +{result.earned}</p><p>Score: {result.score}. {result.coins===0?"This mission gives score only.":result.earned<result.coins?"Your daily NexadortCoin limit reduced this reward.":"The NexadortCoins were added to your profile."}</p><button className="primary" onClick={start}><Play/> Play again</button><button className="secondary" onClick={onClose}>Back to Arcade</button></>}</div>}
    <div className="xp-rule"><CoinMark/><span>Win or score in this mission to earn 3–30 NexadortCoins · No daily cap</span></div>
  </div></div>;
}

function drawGrid(ctx: CanvasRenderingContext2D, c: HTMLCanvasElement, color: string) { ctx.strokeStyle=color;ctx.lineWidth=1;for(let x=0;x<c.width;x+=40){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,c.height);ctx.stroke()}for(let y=0;y<c.height;y+=40){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(c.width,y);ctx.stroke()} }
function drawGlow(ctx:CanvasRenderingContext2D,x:number,y:number,r:number,color:string){ctx.save();ctx.shadowBlur=15;ctx.shadowColor=color;ctx.fillStyle=color;ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill();ctx.restore()}
function drawCharacter(ctx:CanvasRenderingContext2D,x:number,y:number,image:string,width:number,height:number,blink:boolean){ctx.save();ctx.globalAlpha=blink?.55:1;const img=getImage(image);ctx.shadowColor="#031b20aa";ctx.shadowBlur=10;ctx.beginPath();ctx.roundRect(x-width/2,y-height/2,width,height,9);ctx.clip();if(img.complete&&img.naturalWidth)ctx.drawImage(img,x-width/2,y-height/2,width,height);else{ctx.fillStyle="#20c997";ctx.fill()}ctx.restore();ctx.save();ctx.strokeStyle="#d8fff0";ctx.lineWidth=2;ctx.beginPath();ctx.roundRect(x-width/2,y-height/2,width,height,9);ctx.stroke();ctx.restore()}
function drawArena(ctx:CanvasRenderingContext2D,c:HTMLCanvasElement){ctx.strokeStyle="#76ffd52d";ctx.lineWidth=1;for(let x=0;x<c.width;x+=48){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,c.height);ctx.stroke()}for(let y=0;y<c.height;y+=48){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(c.width,y);ctx.stroke()}ctx.strokeStyle="#8bffe0";ctx.lineWidth=3;ctx.strokeRect(18,18,c.width-36,c.height-36);ctx.fillStyle="#d7ff6950";ctx.beginPath();ctx.arc(c.width/2,c.height/2,75,0,Math.PI*2);ctx.fill()}
function drawLandscape(ctx:CanvasRenderingContext2D,c:HTMLCanvasElement){ctx.fillStyle="#071d2733";for(let i=0;i<8;i++){ctx.beginPath();ctx.arc(50+i*105,340-(i%3)*35,45,0,Math.PI*2);ctx.fill()}ctx.strokeStyle="#dfffa918";ctx.lineWidth=2;for(let i=0;i<7;i++){ctx.beginPath();ctx.moveTo(0,i*70);ctx.lineTo(c.width,i*70-50);ctx.stroke()}}
function drawSkyline(ctx:CanvasRenderingContext2D,camera:number){ctx.fillStyle="#145c6760";for(let i=0;i<12;i++){const x=i*105-camera*.18;const h=80+(i%4)*28;ctx.fillRect(x,350-h,80,h);ctx.fillStyle="#b9ffdd70";for(let w=0;w<3;w++)ctx.fillRect(x+12+w*21,365-h,8,12);ctx.fillStyle="#145c6760"}}
function drawMovingCity(ctx:CanvasRenderingContext2D,now:number){const shift=(now/18)%150;ctx.fillStyle="#18786a55";for(let i=-1;i<7;i++){const x=i*150-shift;const h=100+(i%3)*35;ctx.fillRect(x,350-h,110,h);ctx.fillStyle="#d8ffcb70";for(let w=0;w<4;w++)ctx.fillRect(x+12+w*24,365-h,10,15);ctx.fillStyle="#18786a55"}}
function drawFacility(ctx:CanvasRenderingContext2D,c:HTMLCanvasElement){ctx.strokeStyle="#78ffcf24";ctx.lineWidth=2;ctx.strokeRect(20,20,c.width-40,c.height-40);ctx.fillStyle="#091c2588";[[165,20,20,210],[300,170,170,20],[520,20,20,220],[170,290,180,20],[500,290,170,20]].forEach(([x,y,w,h])=>ctx.fillRect(x,y,w,h))}
function drawField(ctx:CanvasRenderingContext2D,c:HTMLCanvasElement){ctx.strokeStyle="#d9fff0aa";ctx.lineWidth=2;for(let y=35;y<c.height;y+=65){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(c.width,y);ctx.stroke()}ctx.fillStyle="#b9ff8e44";ctx.fillRect(0,0,c.width,36);ctx.fillRect(0,c.height-36,c.width,36);ctx.font="bold 11px Arial";ctx.fillStyle="#fff";ctx.fillText("SCORE LINE",12,23)}
function drawRoad(ctx:CanvasRenderingContext2D,c:HTMLCanvasElement,now:number){const sky=ctx.createLinearGradient(0,0,0,c.height);sky.addColorStop(0,"#0a2b38");sky.addColorStop(1,"#11635d");ctx.fillStyle=sky;ctx.fillRect(0,0,c.width,c.height);ctx.fillStyle="#17282e";ctx.beginPath();ctx.moveTo(180,0);ctx.lineTo(540,0);ctx.lineTo(610,c.height);ctx.lineTo(110,c.height);ctx.closePath();ctx.fill();ctx.strokeStyle="#5effc7";ctx.lineWidth=4;ctx.stroke();ctx.setLineDash([24,24]);ctx.lineDashOffset=now/20;ctx.strokeStyle="#f5d85d";ctx.lineWidth=3;[305,415].forEach(x=>{ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,c.height);ctx.stroke()});ctx.setLineDash([])}
function drawMountain(ctx:CanvasRenderingContext2D,c:HTMLCanvasElement){const sky=ctx.createLinearGradient(0,0,0,c.height);sky.addColorStop(0,"#88dfe2");sky.addColorStop(1,"#f8fff4");ctx.fillStyle=sky;ctx.fillRect(0,0,c.width,c.height);ctx.fillStyle="#80aaa5";ctx.beginPath();ctx.moveTo(0,390);ctx.lineTo(150,190);ctx.lineTo(250,275);ctx.lineTo(390,80);ctx.lineTo(510,235);ctx.lineTo(650,45);ctx.lineTo(720,130);ctx.lineTo(720,400);ctx.closePath();ctx.fill();ctx.strokeStyle="#effff9";ctx.lineWidth=8;ctx.stroke()}
function drawRock(ctx:CanvasRenderingContext2D,x:number,y:number,r:number){ctx.fillStyle="#38575b";ctx.beginPath();for(let i=0;i<7;i++){const a=i/7*Math.PI*2,rr=r*(i%2?0.72:1);const px=x+Math.cos(a)*rr,py=y+Math.sin(a)*rr;if(i===0)ctx.moveTo(px,py);else ctx.lineTo(px,py)}ctx.closePath();ctx.fill()}
function drawOcean(ctx:CanvasRenderingContext2D,c:HTMLCanvasElement,now:number){const sea=ctx.createLinearGradient(0,0,c.width,c.height);sea.addColorStop(0,"#087e9e");sea.addColorStop(1,"#04b89e");ctx.fillStyle=sea;ctx.fillRect(0,0,c.width,c.height);ctx.strokeStyle="#c8fff27a";ctx.lineWidth=3;for(let y=30;y<c.height;y+=45){ctx.beginPath();for(let x=0;x<c.width;x+=12){const py=y+Math.sin(x/35+now/450)*6;if(x===0)ctx.moveTo(x,py);else ctx.lineTo(x,py)}ctx.stroke()}ctx.fillStyle="#efdc9c";ctx.fillRect(0,0,55,c.height);ctx.fillStyle="#075d62";ctx.fillRect(45,0,8,c.height)}
function drawGoal(ctx:CanvasRenderingContext2D,c:HTMLCanvasElement){ctx.fillStyle="#0a8c64";ctx.fillRect(0,0,c.width,c.height);ctx.strokeStyle="#effff8";ctx.lineWidth=3;ctx.strokeRect(70,25,c.width-140,c.height-45);ctx.beginPath();ctx.arc(c.width/2,155,65,0,Math.PI*2);ctx.stroke();ctx.fillStyle="#092f37aa";ctx.fillRect(80,330,c.width-160,55);ctx.strokeStyle="#fff";ctx.strokeRect(80,330,c.width-160,55)}
const imageCache=new Map<string,HTMLImageElement>();function getImage(src:string){let img=imageCache.get(src);if(!img){img=new Image();img.src=src;imageCache.set(src,img)}return img}
