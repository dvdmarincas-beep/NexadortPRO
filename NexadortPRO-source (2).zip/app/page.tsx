'use client';

import { useEffect, useRef, useState } from 'react';
import {
  ArrowLeft, ArrowRight, ArrowUp, Bot, Check, ChevronRight, Code2, Download,
  Gamepad2, Home, ImagePlus, LockKeyhole, Medal, Mic, MicOff, Palette,
  Play, Save, Settings, ShieldCheck, ShoppingBag, Sparkles, Square, Star,
  Target, Trophy, Upload, UserRound, Volume2, Zap
} from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import MiniGames from './mini-games';
import ShortsPanel from './shorts-panel';
import { ArcadeGame, Difficulty, Game, Profile, ShopItem, allItems, arcadeGames, avatars, defaultProfile, games, gear, today } from './game-data';

type Page = 'home' | 'arcade' | 'shop' | 'shorts' | 'profile' | 'settings';
type Message = { role:'user'|'assistant'; content:string; error?:boolean; guide?:boolean };
type InstallPrompt={prompt:()=>Promise<void>;userChoice:Promise<{outcome:'accepted'|'dismissed'}>};
const YOUTUBE_CHANNEL='https://www.youtube.com/channel/UCWok-VgNs5FfnzQahZ2w3XA';

const gameIcons={brawl:Trophy,fortnite:Gamepad2,roblox:Code2};
const arcadeIcons:Record<ArcadeGame,typeof Trophy>={brawl:Trophy,fortnite:ShieldCheck,roblox:Code2,stealth:LockKeyhole,runner:Zap,touchdown:Medal,racing:ArrowRight,mountain:Target,ocean:ShieldCheck,goalkeeper:Trophy,tysonfly:Zap,rocketleague:Gamepad2};
const achievements=[
 {id:'first-game',name:'First Mission',description:'Complete your first Arcade mission.',goal:1},
 {id:'ten-games',name:'Arcade Regular',description:'Complete 10 Arcade missions.',goal:10},
 {id:'twenty-five-games',name:'Arcade Expert',description:'Complete 25 Arcade missions.',goal:25},
 {id:'score-25',name:'Point Hunter',description:'Earn 25 total score.',goal:25},
 {id:'score-100',name:'Century Club',description:'Earn 100 total score.',goal:100},
 {id:'six-wins',name:'Six-Mode Champion',description:'Win at least 6 missions.',goal:6},
 {id:'collector',name:'Collector',description:'Own 5 shop items.',goal:5},
];

function normalizeProfile(value:any):Profile{
 const legacy:Record<string,string>={panda:'agent-panda',storm:'storm-scout',crystal:'crystal-hero',builder:'master-builder',crown:'arena-legend',nebula:'nebula-panda','brawler-ranger':'ranger-brawler','brawler-tank':'tank-brawler','brawler-mythic':'mythic-brawler','skin-neon':'neon-striker','skin-storm':'storm-guardian','skin-cosmic':'cosmic-champion','outfit-block':'block-adventurer','outfit-coder':'code-master','outfit-galaxy':'galaxy-creator'};
 const stats={...defaultProfile.stats,...(value?.stats||{}),best:{...defaultProfile.stats.best,...(value?.stats?.best||{})},wins:{...defaultProfile.stats.wins,...(value?.stats?.wins||{})}};
 const owned=(value?.owned||[]).map((id:string)=>legacy[id]||id);const equipped=Object.fromEntries(Object.entries({...defaultProfile.equipped,...(value?.equipped||{})}).map(([game,id])=>[game,legacy[String(id)]||id]));
 return {...defaultProfile,...value,name:!value?.name||value.name==='Player'?'NexadortPRO':value.name,avatar:legacy[value?.avatar]||value?.avatar||'agent-panda',owned:Array.from(new Set(['agent-panda',...owned])),equipped,stats,achievements:value?.achievements||[]};
}
function Panda({speaking=false}:{speaking?:boolean}){
 return <div className={`standing-panda ${speaking?'is-speaking':''}`}><img className="panda-closed" src="/panda-standing-closed.jpg" alt="Standing NexadortPRO panda assistant"/><img className="panda-open" src="/panda-standing-open.jpg" alt="" aria-hidden="true"/></div>
}
function Avatar({profile,size='normal'}:{profile:Profile;size?:'small'|'normal'|'large'}){
 const image=profile.customAvatar&&profile.avatar==='custom'?profile.customAvatar:avatars.find(a=>a.id===profile.avatar)?.image||avatars[0].image;
 return <img className={`avatar ${size}`} src={image} alt="Player profile"/>;
}
function ProgressBar({value,max=100}:{value:number;max?:number}){return <div className="progress-track"><span style={{width:`${Math.min(100,value/max*100)}%`}}/></div>}
function CoinMark({size='normal'}:{size?:'small'|'normal'|'large'}){return <img className={`coin-mark ${size}`} src="/nexadort-coin.webp" alt="NexadortCoin"/>}

export default function App(){
 const [page,setPage]=useState<Page>('home');
 const [chat,setChat]=useState<Game|null>(null);
 const [profile,setProfile]=useState<Profile>(defaultProfile);
 const [ready,setReady]=useState(false);
 const [filter,setFilter]=useState<'all'|'avatar'|Game>('all');
 const [playMode,setPlayMode]=useState<ArcadeGame|null>(null);
 const [toast,setToast]=useState('');
 const [text,setText]=useState('');
 const [messages,setMessages]=useState<Message[]>([]);
 const [busy,setBusy]=useState(false);
 const [mode,setMode]=useState<'loading'|'guide'|'ai'|'error'>('loading');
 const [installPrompt,setInstallPrompt]=useState<InstallPrompt|null>(null);
 const [voice,setVoice]=useState(false),[speaking,setSpeaking]=useState(false),[listening,setListening]=useState(false),[notice,setNotice]=useState('');
 const recognition=useRef<any>(null),controller=useRef<AbortController|null>(null),voiceRef=useRef(false),lock=useRef(false),end=useRef<HTMLDivElement>(null);

 useEffect(()=>{try{const stored=localStorage.getItem('nexasort-profile-v2');if(stored)setProfile(normalizeProfile(JSON.parse(stored)))}catch{}setReady(true);fetch('/api/chat').then(r=>r.json()).then(d=>setMode(d.mode==='demo'?'guide':d.mode)).catch(()=>setMode('error'));return()=>{controller.current?.abort();recognition.current?.abort();speechSynthesis?.cancel()}},[]);
 useEffect(()=>{if(ready)localStorage.setItem('nexasort-profile-v2',JSON.stringify(profile))},[profile,ready]);
 useEffect(()=>{end.current?.scrollIntoView({behavior:'smooth',block:'nearest'})},[messages,busy]);
 useEffect(()=>{const capture=(event:Event)=>{event.preventDefault();setInstallPrompt(event as Event&InstallPrompt)};const installed=()=>{setInstallPrompt(null);flash('NexadortPRO was installed!')};window.addEventListener('beforeinstallprompt',capture);window.addEventListener('appinstalled',installed);if('serviceWorker' in navigator)navigator.serviceWorker.register('/sw.js').catch(()=>{});return()=>{window.removeEventListener('beforeinstallprompt',capture);window.removeEventListener('appinstalled',installed)}},[]);

 function flash(message:string){setToast(message);window.setTimeout(()=>setToast(''),2600)}
 async function installApp(){if(window.matchMedia('(display-mode: standalone)').matches){flash('NexadortPRO is already installed.');return}if(installPrompt){await installPrompt.prompt();const choice=await installPrompt.userChoice;if(choice.outcome==='accepted')setInstallPrompt(null);else flash('Installation was cancelled.');return}flash('In Chrome, open the menu and choose Install NexadortPRO.');}
 function navigate(next:Page){setPage(next);setChat(null);setMessages([]);setText('');stopVoice();window.scrollTo({top:0,behavior:'smooth'})}
 function openChat(game:Game){setChat(game);setMessages([]);setText('');stopVoice();window.scrollTo({top:0,behavior:'smooth'})}
 function stopVoice(){window.speechSynthesis?.cancel();setSpeaking(false)}
 function speak(value:string){stopVoice();if(!('speechSynthesis' in window)){setNotice('Text-to-speech is not available in this browser.');return}const u=new SpeechSynthesisUtterance(value);u.lang='en-US';u.rate=1;u.onstart=()=>setSpeaking(true);u.onend=()=>setSpeaking(false);u.onerror=()=>{setSpeaking(false);setNotice('Voice playback could not start.')};window.speechSynthesis.speak(u)}
 function microphone(){if(listening){recognition.current?.stop();return}const R=(window as any).SpeechRecognition||(window as any).webkitSpeechRecognition;if(!R){setNotice('Voice typing works best in Google Chrome.');return}const r=new R();recognition.current=r;r.lang='en-US';r.interimResults=false;r.onstart=()=>{setListening(true);setNotice('Listening…')};r.onresult=(e:any)=>{setText(v=>(v+' '+e.results[0][0].transcript).trim());setNotice('Check your message, then press Send.')};r.onerror=(e:any)=>{setNotice(e.error==='not-allowed'?'Allow microphone access in Chrome site settings.':'I could not hear that. Try again.');setListening(false)};r.onend=()=>setListening(false);r.start()}
 async function send(value=text){if(!chat||!value.trim()||lock.current)return;lock.current=true;setBusy(true);setNotice('');const next=[...messages,{role:'user',content:value.trim()} as Message];setMessages(next);setText('');const ac=new AbortController();controller.current=ac;try{const r=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({game:chat,messages:next.filter(m=>!m.error).slice(-12).map(({role,content})=>({role,content}))}),signal:ac.signal});const d=await r.json();const answer:Message={role:'assistant',content:d.answer||'No answer was returned.',error:!r.ok||d.error,guide:d.mode==='guide'||d.mode==='demo'};setMessages(m=>[...m,answer]);if(voiceRef.current&&!answer.error)speak(answer.content)}catch{if(!ac.signal.aborted)setMessages(m=>[...m,{role:'assistant',content:'The connection was interrupted. Try again.',error:true}])}finally{if(!ac.signal.aborted){setBusy(false);lock.current=false}}}

 function purchase(item:ShopItem){
  const owned=profile.owned.includes(item.id);
  if(!owned&&profile.xp<item.price){flash(`You need ${item.price-profile.xp} more NexadortCoins.`);return}
  setProfile(p=>({...p,xp:owned?p.xp:p.xp-item.price,owned:owned?p.owned:[...p.owned,item.id],avatar:item.kind==='avatar'?item.id:p.avatar,equipped:item.game?{...p.equipped,[item.game]:item.id}:p.equipped}));
  if(!owned&&profile.owned.length+1>=5)setProfile(p=>({...p,achievements:Array.from(new Set([...p.achievements,'collector']))}));
  flash(owned?'Item equipped!':'Unlocked and equipped!');
 }
 function finishGame(game:ArcadeGame,score:number,won:boolean,reward:number){
  const date=today(),used=profile.dailyDate===date?profile.dailyXp:0,earned=Math.max(0,reward);
  setProfile(p=>{const played=p.stats.gamesPlayed+1,total=p.stats.totalScore+score,wins={...p.stats.wins,[game]:p.stats.wins[game]+(won?1:0)},best={...p.stats.best,[game]:Math.max(p.stats.best[game],score)};const ownedCount=p.owned.length,totalWins=Object.values(wins).reduce((a,b)=>a+b,0);const unlocked=new Set(p.achievements);if(played>=1)unlocked.add('first-game');if(played>=10)unlocked.add('ten-games');if(played>=25)unlocked.add('twenty-five-games');if(total>=25)unlocked.add('score-25');if(total>=100)unlocked.add('score-100');if(totalWins>=6)unlocked.add('six-wins');if(ownedCount>=5)unlocked.add('collector');return {...p,xp:p.xp+earned,dailyXp:used+earned,dailyDate:date,stats:{gamesPlayed:played,totalScore:total,wins,best},achievements:[...unlocked]}});
  return earned;
 }
 function addCoins(amount:number){const date=today();setProfile(p=>{const used=p.dailyDate===date?p.dailyXp:0;return {...p,xp:p.xp+amount,dailyXp:used+amount,dailyDate:date}})}
 const chatInfo=chat?games[chat]:null,ChatIcon=chat?gameIcons[chat]:Bot;
 const daily=profile.dailyDate===today()?profile.dailyXp:0;
 const careerPoints=profile.stats.totalScore+profile.stats.gamesPlayed*5;
 const level=Math.floor(careerPoints/50)+1,levelProgress=careerPoints%50;
 const questValues=[Math.min(1,profile.stats.gamesPlayed),Math.min(3,Object.values(profile.stats.wins).reduce((a,b)=>a+b,0)),Math.min(5,profile.owned.length)];
 const nav=[['home','Home',Home],['arcade','Arcade',Gamepad2],['shop','Shop',ShoppingBag],['shorts','Shorts',Play],['profile','Profile',UserRound],['settings','Settings',Settings]] as const;

 return <div className="app-shell">
  {toast&&<div className="toast"><Check/>{toast}</div>}
  <header className="topbar"><button className="brand" onClick={()=>navigate('home')}><span className="brand-icon"><Gamepad2/></span><span>NEXADORT<span>PRO</span><small>GAME AI + ARCADE</small></span></button><nav>{nav.map(([id,label,Icon])=><button key={id} className={page===id&&!chat?'active':''} onClick={()=>navigate(id)}><Icon/><span>{label}</span></button>)}</nav><button className="player-pill" onClick={()=>navigate('profile')}><Avatar profile={profile} size="small"/><span><b>{profile.name}</b><small><CoinMark size="small"/>{profile.xp}</small></span></button></header>

  {chat?<main className="chat-page"><button className="back" onClick={()=>setChat(null)}><ArrowLeft/> Back</button><div className="chat-layout"><aside className="panda-panel"><Panda speaking={speaking}/><div className="panda-about"><span>GAMING ASSISTANT</span><h2>Panda</h2><p>{speaking?'Panda is talking':listening?'Listening to you':busy?'Thinking…':`Ask about ${chatInfo!.name}`}</p><div className={`equalizer ${speaking?'active':''}`}>{Array.from({length:13},(_,i)=><i key={i}/>)}</div></div><div className="voice-control"><Volume2/><label>Read answers aloud</label><Switch checked={voice} onCheckedChange={v=>{setVoice(v);voiceRef.current=v;if(!v)stopVoice()}}/></div>{speaking&&<button className="stop-voice" onClick={stopVoice}><Square/> Stop voice</button>}<div className="topic-note"><ShieldCheck/> This chat only answers questions about <strong>{chatInfo!.name}</strong>.</div></aside><section className="chat-window"><div className="chat-header"><span className={`game-chip ${chatInfo!.color}`}>{chatInfo!.name}</span><b>Chat with Panda</b><span className="mode-badge">{mode==='ai'?'Live AI':mode==='guide'?'Smart guide':'Connecting…'}</span></div><div className="conversation">{messages.length===0?<div className="welcome"><span className={`welcome-icon ${chatInfo!.color}`}><ChatIcon/></span><h2>Ask Panda about<br/>{chatInfo!.name}.</h2><p>{mode==='ai'?'Live AI is connected. Ask by text or voice.':'Smart Guide answers many common questions even without live AI.'}</p><div className="suggestions">{chatInfo!.prompts.map(p=><button key={p} onClick={()=>send(p)}>{p}<ChevronRight/></button>)}</div></div>:messages.map((m,i)=><div key={i} className={`message ${m.role} ${m.error?'error-message':''}`}><small>{m.role==='user'?'You':m.error?'Error':`Panda${m.guide?' · Smart Guide':''}`}</small><p>{m.content}</p>{m.role==='assistant'&&!m.error&&<button onClick={()=>speak(m.content)}><Volume2/> Listen</button>}</div>)}{busy&&<div className="thinking"><Sparkles/> Panda is thinking…</div>}<div ref={end}/></div><div className="composer-area">{notice&&<p className="notice">{notice}</p>}<form className="composer" onSubmit={e=>{e.preventDefault();send()}}><textarea value={text} onChange={e=>setText(e.target.value)} placeholder={`Ask about ${chatInfo!.name}…`} maxLength={2500} onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send()}}}/><button type="button" className={listening?'recording':''} onClick={microphone}>{listening?<MicOff/>:<Mic/>}</button><button className="send-button" disabled={!text.trim()||busy}><ArrowUp/></button></form></div></section></div></main>
  :page==='home'?<HomePage profile={profile} daily={daily} questValues={questValues} level={level} levelProgress={levelProgress} installApp={installApp} installReady={Boolean(installPrompt)} openChat={openChat} navigate={navigate}/>
  :page==='arcade'?<ArcadePage profile={profile} play={setPlayMode}/>
  :page==='shop'?<ShopPage profile={profile} filter={filter} setFilter={setFilter} purchase={purchase}/>
  :page==='shorts'?<ShortsPanel/>
  :page==='profile'?<ProfilePage profile={profile} setProfile={setProfile} flash={flash}/>
  :<SettingsPage/>}

  <footer><span>NEXADORTPRO / GAME AI + ARCADE</span><span>Unofficial fan project · Progress is stored on this device</span></footer>
  {playMode&&<MiniGames mode={playMode} profile={profile} onClose={()=>setPlayMode(null)} onFinish={finishGame} onCoin={addCoins}/>}
 </div>
}

function HomePage({profile,daily,questValues,level,levelProgress,installApp,installReady,openChat,navigate}:{profile:Profile;daily:number;questValues:number[];level:number;levelProgress:number;installApp:()=>void;installReady:boolean;openChat:(g:Game)=>void;navigate:(p:Page)=>void}){
 return <main className="home-page">
  <section className="hero"><div className="hero-copy"><span className="eyebrow"><Sparkles/> NEXADORTPRO GAMING UNIVERSE</span><h1>Chat. Play.<br/><em>Level up.</em></h1><p>Ask Panda, play ten longer and harder Arcade missions, complete challenges and build your NexadortPRO career.</p><div className="hero-actions"><button className="primary" onClick={()=>navigate('arcade')}><Play/> Play Arcade</button><button className="install-button" onClick={installApp}><Download/> {installReady?'Install App':'Download App'}</button><a className="youtube-button" href={YOUTUBE_CHANNEL} target="_blank" rel="noreferrer"><Play/> Nexadort YouTube Channel</a><button className="secondary" onClick={()=>navigate('profile')}><Trophy/> View Career</button></div><div className="slow-xp"><CoinMark/> Every Arcade mission can earn NexadortCoins. Win missions and beat your score.</div></div><div className="hero-mascot"><Panda/><div><b>PANDA ONLINE</b><span>NexadortPRO gaming guide & arcade host</span></div></div></section>
  <section className="dashboard-strip"><div><span>CAREER LEVEL</span><b><Trophy/>Level {level}</b><ProgressBar value={levelProgress} max={50}/></div><div><span>MISSIONS PLAYED</span><b><Gamepad2/>{profile.stats.gamesPlayed}</b></div><div><span>NEXADORTCOINS</span><b><CoinMark/>{profile.xp}</b></div><div><span>COINS TODAY</span><b>{daily}</b><ProgressBar value={daily}/></div></section>
  <section className="section"><div className="section-heading"><div><span>01 · GAME GUIDE</span><h2>Choose a game chat</h2></div><p>Ask through text or your Chrome microphone.</p></div><div className="game-grid">{(Object.keys(games) as Game[]).map((g,i)=>{const info=games[g],Icon=gameIcons[g];return <button className={`game-card ${info.color}`} key={g} onClick={()=>openChat(g)}><span className="card-top"><Icon/><small>0{i+1}</small></span><strong>{info.name}</strong><span className="card-bottom"><small>{info.tag}</small><span><ArrowRight/></span></span></button>})}</div></section>
  <section className="section mode-section"><div className="section-heading"><div><span>02 · TEN HARD ARCADE MODES</span><h2>Pick a new challenge</h2></div><button className="text-button" onClick={()=>navigate('arcade')}>See all games <ArrowRight/></button></div><div className="mode-gallery">{(Object.keys(arcadeGames) as ArcadeGame[]).map(g=>{const info=arcadeGames[g];return <button key={g} onClick={()=>navigate('arcade')}><img src={info.image} alt=""/><span><small>{info.name} · {info.duration}s · {info.difficulty}</small><b>{info.short}</b></span></button>})}</div></section>
  <section className="home-bottom"><div className="quest-panel"><div className="section-heading"><div><span>03 · CHALLENGES</span><h2>Progress goals</h2></div></div>{[['Play one mission',questValues[0],1],['Win three missions',questValues[1],3],['Own five shop items',questValues[2],5]].map(([name,value,max])=><div className="quest-row" key={String(name)}><Target/><div><b>{name}</b><ProgressBar value={Number(value)} max={Number(max)}/></div><span>{value}/{max}</span></div>)}</div><button className="collection-banner" onClick={()=>navigate('profile')}><span><Trophy/><b>Player career road</b><small>Level {level} · {levelProgress}/50 points to the next level · 7 achievements</small></span><ArrowRight/></button></section>
 </main>
}

function ArcadePage({profile,play}:{profile:Profile;play:(g:ArcadeGame)=>void}){
 const [difficulty,setDifficulty]=useState<'all'|Difficulty>('all');
 const modes=(Object.keys(arcadeGames) as ArcadeGame[]).filter(g=>difficulty==='all'||arcadeGames[g].difficulty===difficulty);
 return <main className="content-page"><div className="page-heading"><span className="eyebrow"><Gamepad2/> HARD ARCADE</span><h1>Eleven realistic challenges.</h1><p>Every mode has different controls, objectives and realistic characters. Pick a tier and test your limits.</p></div><div className="filters arcade-filters">{(['all','Easy','Medium','Hard','Impossible'] as const).map(level=><button key={level} className={difficulty===level?'active':''} onClick={()=>setDifficulty(level)}>{level==='all'?'All tiers':level}</button>)}</div><div className="arcade-grid">{modes.map(g=>{const info=arcadeGames[g],Icon=arcadeIcons[g],core=g==='brawl'||g==='fortnite'||g==='roblox'?g:null,equipped=core?allItems.find(i=>i.id===profile.equipped[core]):undefined;return <article className={`arcade-card ${info.color}`} key={g}><div className="arcade-art" style={{backgroundImage:`linear-gradient(180deg,transparent 15%,rgba(3,35,37,.86)),url(${info.image})`}}><Icon/><span>{info.short}</span><small>{info.duration} SECONDS · {info.difficulty.toUpperCase()}</small></div><div><span className="game-chip">{info.name}</span><h2>{info.short}</h2><p>{info.description}</p><div className="best-score"><Star/> Best score: <b>{profile.stats.best[g]}</b><Trophy/> Wins: <b>{profile.stats.wins[g]}</b></div>{equipped?<div className="equipped-preview"><img src={equipped.image} alt=""/><span><small>EQUIPPED PERK</small><b>{equipped.name}</b><em>{equipped.perk}</em></span></div>:<div className="equipped-preview mode-character"><img src={info.image} alt=""/><span><small>REALISTIC MODE CHARACTER</small><b>{info.name} specialist</b><em>Created especially for this mission.</em></span></div>}<button className="dark-button" onClick={()=>play(g)}><Play/> Play {info.difficulty} mission</button></div></article>})}</div><div className="arcade-reward-note"><CoinMark size="large"/><span><b>Earn NexadortCoins</b><small>Every Arcade mission rewards coins based on score and victory.</small></span></div></main>
}

function ShopPage({profile,filter,setFilter,purchase}:{profile:Profile;filter:'all'|'avatar'|Game;setFilter:(f:'all'|'avatar'|Game)=>void;purchase:(i:ShopItem)=>void}){
 const list=allItems.filter(i=>filter==='all'||filter==='avatar'?filter==='all'||i.kind==='avatar':i.game===filter);
 return <main className="content-page"><div className="page-heading shop-heading"><div><span className="eyebrow"><ShoppingBag/> NEXADORTCOIN SHOP</span><h1>Characters that work.</h1><p>Every card uses real rendered character art. Game items change your look and unlock the perk written on the card.</p></div><div className="xp-wallet"><CoinMark size="large"/><b>{profile.xp}</b><span>NEXADORTCOINS</span></div></div><div className="filters">{([['all','All'],['avatar','Profile pictures'],['brawl','Brawl items'],['fortnite','Fortnite skins'],['roblox','Roblox outfits']] as const).map(([id,label])=><button className={filter===id?'active':''} key={id} onClick={()=>setFilter(id)}>{label}</button>)}</div><div className="shop-grid">{list.map(item=>{const owned=profile.owned.includes(item.id),equipped=item.kind==='avatar'?profile.avatar===item.id:item.game&&profile.equipped[item.game]===item.id;return <article className={`shop-item ${equipped?'selected-item':''}`} key={item.id}><div className="shop-image"><img src={item.image} alt={item.name}/>{equipped&&<span><Check/> EQUIPPED</span>}</div><small>{item.kind==='avatar'?'PROFILE PICTURE':item.kind.toUpperCase()}</small><h3>{item.name}</h3><p>{item.perk}</p><button className={equipped?'equipped':''} onClick={()=>purchase(item)}>{equipped?<><Check/> Equipped</>:owned?<><Palette/> Equip</>:item.price===0?<><Check/> Free</>:<><CoinMark size="small"/> {item.price} Coins</>}</button></article>})}</div></main>
}

function ProfilePage({profile,setProfile,flash}:{profile:Profile;setProfile:React.Dispatch<React.SetStateAction<Profile>>;flash:(s:string)=>void}){
 const [name,setName]=useState(profile.name);const input=useRef<HTMLInputElement>(null);const currentDaily=profile.dailyDate===today()?profile.dailyXp:0;const careerPoints=profile.stats.totalScore+profile.stats.gamesPlayed*5,level=Math.floor(careerPoints/50)+1,levelProgress=careerPoints%50;
 function upload(e:React.ChangeEvent<HTMLInputElement>){const file=e.target.files?.[0];if(!file)return;if(!file.type.startsWith('image/')){flash('Choose an image file.');return}if(file.size>2_000_000){flash('Choose an image smaller than 2 MB.');return}const reader=new FileReader();reader.onload=()=>setProfile(p=>({...p,customAvatar:String(reader.result),avatar:'custom'}));reader.readAsDataURL(file)}
 return <main className="content-page"><div className="page-heading"><span className="eyebrow"><UserRound/> PLAYER PROFILE</span><h1>Your career.</h1><p>Change your name and picture, check ten game records and unlock permanent achievements.</p></div><div className="profile-layout"><section className="profile-card"><Avatar profile={profile} size="large"/><h2>{profile.name}</h2><span className="profile-level"><Trophy/>Career Level {level}</span><div className="career-progress"><div><span>NEXT LEVEL</span><b>{levelProgress}/50</b></div><ProgressBar value={levelProgress} max={50}/><small>Score and completed missions build your permanent career level.</small></div><div className="daily-progress"><div><span>Daily NexadortCoins</span><b>{currentDaily}/100</b></div><ProgressBar value={currentDaily}/><small>{profile.xp} NexadortCoins available · resets each day</small></div><div className="profile-stats"><div><b>{profile.stats.gamesPlayed}</b><span>MISSIONS</span></div><div><b>{Object.values(profile.stats.wins).reduce((a,b)=>a+b,0)}</b><span>WINS</span></div><div><b>{profile.stats.totalScore}</b><span>SCORE</span></div><div><b>{profile.owned.length}</b><span>ITEMS</span></div></div></section><section className="profile-editor"><h2>Player details</h2><label>Display name<input value={name} maxLength={18} onChange={e=>setName(e.target.value)}/></label><button className="primary" onClick={()=>{setProfile(p=>({...p,name:name.trim()||'NexadortPRO'}));flash('Profile saved!')}}><Save/> Save name</button><hr/><h2>Profile picture</h2><p>Unlocked pictures use the exact same images shown in the Shop.</p><div className="avatar-picker">{avatars.filter(a=>profile.owned.includes(a.id)).map(a=><button className={profile.avatar===a.id?'selected':''} key={a.id} onClick={()=>setProfile(p=>({...p,avatar:a.id}))}><img src={a.image} alt={a.name}/>{profile.avatar===a.id&&<Check/>}</button>)}</div><input ref={input} hidden type="file" accept="image/png,image/jpeg,image/webp" onChange={upload}/><button className="secondary" onClick={()=>input.current?.click()}><Upload/> Upload picture</button><small className="file-note">Maximum 2 MB. The image stays on this device.</small><hr/><h2>Game loadouts</h2><div className="equipped-list">{(Object.keys(games) as Game[]).map(g=>{const item=gear.find(x=>x.id===profile.equipped[g]);return <div key={g}><span className={`dot ${games[g].color}`}/><b>{games[g].name}</b>{item?<><img src={item.image} alt=""/><span><b>{item.name}</b><small>{item.perk}</small></span></>:<span>No item equipped</span>}</div>})}</div><hr/><h2>Ten-game records</h2><div className="record-grid">{(Object.keys(arcadeGames) as ArcadeGame[]).map(g=><div key={g}><img src={arcadeGames[g].image} alt=""/><span><b>{arcadeGames[g].short}</b><small>Best {profile.stats.best[g]} · {profile.stats.wins[g]} wins</small></span></div>)}</div><hr/><h2>Achievements</h2><div className="achievement-grid">{achievements.map(a=>{const open=profile.achievements.includes(a.id);return <div className={open?'unlocked':''} key={a.id}>{open?<Medal/>:<LockKeyhole/>}<span><b>{a.name}</b><small>{a.description}</small></span></div>})}</div></section></div></main>
}

function SettingsPage(){
 const [slug,setSlug]=useState('nexadortpro-game');
 const [customDomain,setCustomDomain]=useState('nexadortpro.com');
 function openSiteManager(){window.open('https://chatgpt.com','_blank','noopener,noreferrer')}
 return <main className="content-page settings-page"><div className="page-heading"><span className="eyebrow"><Settings/> SITE SETTINGS</span><h1>Change your URL.</h1><p>Use the Site manager to change the public URL label. The old address will redirect automatically.</p></div><section className="settings-card"><div className="settings-icon"><Settings/></div><div><h2>ChatGPT Sites URL</h2><p>Choose a lowercase name with at least five characters. Example: <b>{slug}</b></p><label>New URL label<input value={slug} onChange={e=>setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g,''))} placeholder="nexadortpro-game"/></label><button className="primary" onClick={openSiteManager}><Settings/> Open URL settings</button><small>After opening Sites, choose this project, then select <b>Settings → Site URL → Change URL</b>.</small></div></section><section className="settings-card custom-domain-card"><div className="settings-icon"><span>.com</span></div><div><h2>Custom .com domain</h2><p>Use a clean address such as <b>{customDomain}</b>. You must own the domain first.</p><label>Your .com domain<input value={customDomain} onChange={e=>setCustomDomain(e.target.value.toLowerCase().replace(/[^a-z0-9.-]/g,''))} placeholder="nexadortpro.com"/></label><button className="primary" onClick={openSiteManager}><Settings/> Open custom-domain setup</button><small>In Sites, choose <b>Settings → Add domain</b>, enter your domain, then add the DNS records shown by Sites at the company where you bought the domain. A .com domain is not free.</small></div></section></main>
}
