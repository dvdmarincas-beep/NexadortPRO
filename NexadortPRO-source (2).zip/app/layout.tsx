import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "NexadortPRO · Game AI + Shorts",
  description: "NexadortPRO gaming app with Panda AI, Arcade missions, real Shorts uploads and player profiles.",
  manifest: "/manifest.webmanifest",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/shop/agent-panda.webp",
    shortcut: "/shop/agent-panda.webp",
    apple: "/shop/agent-panda.webp",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head><meta name="theme-color" content="#079da6"/><meta name="apple-mobile-web-app-capable" content="yes"/><meta name="apple-mobile-web-app-title" content="NexadortPRO"/></head>
      <body className="antialiased">{children}</body>
    </html>
  );
}
