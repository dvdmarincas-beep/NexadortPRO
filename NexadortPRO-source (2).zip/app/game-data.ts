export type Game = "brawl" | "fortnite" | "roblox";
export type ArcadeGame = Game | "stealth" | "runner" | "touchdown" | "racing" | "mountain" | "ocean" | "goalkeeper" | "tysonfly" | "rocketleague";
export type Difficulty = "Easy" | "Medium" | "Hard" | "Impossible";
export type ItemKind = "avatar" | "brawler" | "skin" | "outfit";

export type ShopItem = {
  id: string;
  name: string;
  kind: ItemKind;
  game?: Game;
  price: number;
  image: string;
  perk: string;
};

export type PlayerStats = {
  gamesPlayed: number;
  totalScore: number;
  best: Record<ArcadeGame, number>;
  wins: Record<ArcadeGame, number>;
};

export type Profile = {
  name: string;
  avatar: string;
  customAvatar?: string;
  xp: number;
  owned: string[];
  equipped: Record<Game, string>;
  dailyXp: number;
  dailyDate: string;
  stats: PlayerStats;
  achievements: string[];
};

export const games = {
  brawl: {
    name: "Brawl Stars",
    short: "Crystal Clash",
    tag: "MOVE · AUTO-FIRE · DEFEAT RIVALS",
    color: "yellow",
    prompts: [
      "How do I choose a brawler?",
      "How can I aim better?",
      "How do I play as a team?",
      "Which role should I play?",
    ],
  },
  fortnite: {
    name: "Fortnite",
    short: "Storm Survival",
    tag: "LOOT · SAFE ZONE · SURVIVE",
    color: "purple",
    prompts: [
      "How can I practise building?",
      "How can I improve my aim?",
      "How do I choose a landing spot?",
      "How should I rotate to the next zone?",
    ],
  },
  roblox: {
    name: "Roblox Studio",
    short: "Rooftop Obby",
    tag: "RUN · JUMP · REACH THE SKYLINE",
    color: "coral",
    prompts: [
      "How do I create my first part?",
      "Where should I put a script?",
      "How do I test my game?",
      "How do I make a part disappear?",
    ],
  },
} as const;

export const arcadeGames: Record<ArcadeGame,{name:string;short:string;color:string;description:string;duration:number;difficulty:Difficulty;image:string}> = {
  brawl:{name:"Arena Action",short:"Crystal Clash",color:"aqua",description:"Survive tougher enemy squads and collect crystals before the arena is overwhelmed.",duration:90,difficulty:"Medium",image:"/shop/aqua-striker.webp"},
  fortnite:{name:"Survival",short:"Storm Frontier",color:"emerald",description:"Stay inside a very fast safe zone while supplies vanish and storm pressure rises.",duration:85,difficulty:"Impossible",image:"/shop/forest-scout.webp"},
  roblox:{name:"Platform Adventure",short:"Rooftop Obby",color:"mint",description:"Run and jump across a long precision rooftop course with tighter jumps and moving hazards.",duration:100,difficulty:"Hard",image:"/shop/city-runner.webp"},
  stealth:{name:"Stealth",short:"Shadow Escape",color:"navy",description:"Impossible infiltration: dodge alert guards, collect every access card and reach the exit unseen.",duration:85,difficulty:"Impossible",image:"/shop/stealth-agent.webp"},
  runner:{name:"Runner",short:"City Sprint",color:"lime",description:"A relentless city sprint with denser barriers, very short reaction windows and energy tokens.",duration:70,difficulty:"Impossible",image:"/shop/city-runner.webp"},
  touchdown:{name:"Sports",short:"Stadium Rush",color:"teal",description:"Break through faster aggressive defenders and cross the scoring line five times.",duration:75,difficulty:"Hard",image:"/shop/touchdown-star.webp"},
  racing:{name:"Racing",short:"Neon Velocity",color:"gold",description:"Impossible night racing: change lanes at high speed, avoid traffic and survive checkpoint gates.",duration:90,difficulty:"Impossible",image:"/shop/neon-driver.webp"},
  mountain:{name:"Rescue",short:"Summit Rescue",color:"ice",description:"Climb a brutal route through moving rocks, recover medical packs and reach the stranded explorer.",duration:90,difficulty:"Impossible",image:"/shop/mountain-rescuer.webp"},
  ocean:{name:"Ocean Rescue",short:"Coastal Guardian",color:"ocean",description:"Swim through shifting waves and faster hazards, recover every buoy and race the storm meter.",duration:80,difficulty:"Hard",image:"/shop/ocean-rescuer.webp"},
  goalkeeper:{name:"Goalkeeper",short:"Final Save",color:"stadium",description:"Impossible keeper training: read rapid shot angles and protect the goal through a full barrage.",duration:75,difficulty:"Impossible",image:"/shop/goalkeeper.webp"},
  tysonfly:{name:"Tyson Fly",short:"Flappy Tyson",color:"lime",description:"Guide the animated Tyson through the pipes, flap through gaps and beat your best score.",duration:75,difficulty:"Medium",image:"/boxer-dog-skin.png"},
  rocketleague:{name:"Rocket League",short:"Goal Rush",color:"gold",description:"Drive a car against an AI rival in a 3D-style arena. Score five goals before your opponent.",duration:180,difficulty:"Hard",image:"/shop/neon-driver.webp"},
};

export const avatars: ShopItem[] = [
  { id: "agent-panda", name: "Agent Panda", kind: "avatar", price: 0, image: "/shop/agent-panda.webp", perk: "The original NexadortPRO profile." },
  { id: "storm-scout", name: "Storm Scout", kind: "avatar", price: 180, image: "/shop/storm-scout.webp", perk: "A purple storm profile portrait." },
  { id: "crystal-hero", name: "Crystal Hero", kind: "avatar", price: 260, image: "/shop/crystal-hero.webp", perk: "A bright crystal armor portrait." },
  { id: "master-builder", name: "Master Builder", kind: "avatar", price: 360, image: "/shop/master-builder.webp", perk: "A block-building engineer portrait." },
  { id: "arena-legend", name: "Arena Legend", kind: "avatar", price: 600, image: "/shop/arena-legend.webp", perk: "A golden champion portrait." },
  { id: "nebula-panda", name: "Nebula Panda", kind: "avatar", price: 900, image: "/shop/nebula-panda.webp", perk: "A rare cosmic panda portrait." },
  { id: "cyber-ninja", name: "Cyber Ninja", kind: "avatar", price: 720, image: "/shop/cyber-ninja.webp", perk: "A teal stealth profile portrait." },
  { id: "touchdown-star", name: "Stadium Star", kind: "avatar", price: 520, image: "/shop/touchdown-star.webp", perk: "A realistic turquoise sports portrait." },
  { id: "stealth-agent", name: "Shadow Agent", kind: "avatar", price: 680, image: "/shop/stealth-agent.webp", perk: "A realistic stealth profile portrait." },
  { id: "city-runner", name: "City Runner", kind: "avatar", price: 460, image: "/shop/city-runner.webp", perk: "A realistic parkour profile portrait." },
];

export const gear: ShopItem[] = [
  { id: "ranger-brawler", name: "Ranger Brawler", kind: "brawler", game: "brawl", price: 240, image: "/shop/ranger-brawler.webp", perk: "Auto-fire cooldown is 20% faster." },
  { id: "tank-brawler", name: "Tank Brawler", kind: "brawler", game: "brawl", price: 420, image: "/shop/tank-brawler.webp", perk: "Start Crystal Clash with 2 extra hearts." },
  { id: "mythic-brawler", name: "Mythic Brawler", kind: "brawler", game: "brawl", price: 760, image: "/shop/mythic-brawler.webp", perk: "Move 18% faster and collect larger gem drops." },
  { id: "arena-medic", name: "Arena Medic", kind: "brawler", game: "brawl", price: 560, image: "/shop/arena-medic.webp", perk: "Recover one heart halfway through the mission." },
  { id: "aqua-striker", name: "Aqua Striker", kind: "brawler", game: "brawl", price: 880, image: "/shop/aqua-striker.webp", perk: "Move 15% faster and auto-fire 15% faster." },
  { id: "neon-striker", name: "Neon Striker", kind: "skin", game: "fortnite", price: 260, image: "/shop/neon-striker.webp", perk: "Loot gives one extra point." },
  { id: "storm-guardian", name: "Storm Guardian", kind: "skin", game: "fortnite", price: 480, image: "/shop/storm-guardian.webp", perk: "Storm damage is 35% slower." },
  { id: "cosmic-champion", name: "Cosmic Champion", kind: "skin", game: "fortnite", price: 820, image: "/shop/cosmic-champion.webp", perk: "Start with one emergency shield charge." },
  { id: "forest-scout", name: "Forest Scout", kind: "skin", game: "fortnite", price: 580, image: "/shop/forest-scout.webp", perk: "Supply pickups attract from a longer distance." },
  { id: "sky-guardian", name: "Sky Guardian", kind: "skin", game: "fortnite", price: 940, image: "/shop/sky-guardian.webp", perk: "Begin with a shield and take slower storm damage." },
  { id: "tyson", name: "Tyson", kind: "skin", game: "fortnite", price: 100, image: "/boxer-yard-skin.png", perk: "The friendly boxer from the Tyson chase mission." },
  { id: "block-adventurer", name: "Block Adventurer", kind: "outfit", game: "roblox", price: 220, image: "/shop/block-adventurer.webp", perk: "Unlock a double jump in Block Obby." },
  { id: "code-master", name: "Code Master", kind: "outfit", game: "roblox", price: 440, image: "/shop/code-master.webp", perk: "Checkpoints are worth double score." },
  { id: "galaxy-creator", name: "Galaxy Creator", kind: "outfit", game: "roblox", price: 780, image: "/shop/galaxy-creator.webp", perk: "Jump 15% higher and move 12% faster." },
  { id: "metro-builder", name: "Metro Builder", kind: "outfit", game: "roblox", price: 540, image: "/shop/metro-builder.webp", perk: "Checkpoints attract from a longer distance." },
  { id: "future-explorer", name: "Future Explorer", kind: "outfit", game: "roblox", price: 980, image: "/shop/future-explorer.webp", perk: "Double jump, faster movement and a higher jump." },
];

export const allItems = [...avatars, ...gear];

export const defaultProfile: Profile = {
  name: "NexadortPRO",
  avatar: "agent-panda",
  xp: 0,
  owned: ["agent-panda"],
  equipped: { brawl: "", fortnite: "", roblox: "" },
  dailyXp: 0,
  dailyDate: "",
  stats: {
    gamesPlayed: 0,
    totalScore: 0,
    best: { brawl: 0, fortnite: 0, roblox: 0, stealth: 0, runner: 0, touchdown: 0, racing: 0, mountain: 0, ocean: 0, goalkeeper: 0, tysonfly: 0, rocketleague: 0 },
    wins: { brawl: 0, fortnite: 0, roblox: 0, stealth: 0, runner: 0, touchdown: 0, racing: 0, mountain: 0, ocean: 0, goalkeeper: 0, tysonfly: 0, rocketleague: 0 },
  },
  achievements: [],
};

export const today = () => new Date().toISOString().slice(0, 10);
