CREATE TABLE `clips` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_id` text NOT NULL,
	`owner_name` text NOT NULL,
	`title` text NOT NULL,
	`game` text NOT NULL,
	`object_key` text NOT NULL,
	`content_type` text NOT NULL,
	`size_bytes` integer NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `clips_object_key_unique` ON `clips` (`object_key`);--> statement-breakpoint
CREATE INDEX `idx_clips_created_at` ON `clips` (`created_at`);--> statement-breakpoint
CREATE INDEX `idx_clips_game_created_at` ON `clips` (`game`,`created_at`);--> statement-breakpoint
CREATE TABLE `comments` (
	`id` text PRIMARY KEY NOT NULL,
	`clip_id` text NOT NULL,
	`user_id` text NOT NULL,
	`user_name` text NOT NULL,
	`body` text NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (`clip_id`) REFERENCES `clips`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `idx_comments_clip_created_at` ON `comments` (`clip_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `likes` (
	`clip_id` text NOT NULL,
	`user_id` text NOT NULL,
	FOREIGN KEY (`clip_id`) REFERENCES `clips`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_likes_clip_user` ON `likes` (`clip_id`,`user_id`);--> statement-breakpoint
CREATE TABLE `reports` (
	`id` text PRIMARY KEY NOT NULL,
	`clip_id` text NOT NULL,
	`user_id` text NOT NULL,
	`reason` text NOT NULL,
	FOREIGN KEY (`clip_id`) REFERENCES `clips`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_reports_clip_user` ON `reports` (`clip_id`,`user_id`);--> statement-breakpoint
CREATE TABLE `subscriptions` (
	`creator_id` text NOT NULL,
	`user_id` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_subscriptions_creator_user` ON `subscriptions` (`creator_id`,`user_id`);