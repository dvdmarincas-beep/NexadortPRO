export function shortsViewer(request: Request) {
  const id = request.headers.get("oai-authenticated-user-id");
  const email = request.headers.get("oai-authenticated-user-email");
  if (!id || !email) return null;
  const encoded = request.headers.get("oai-authenticated-user-full-name");
  let name = email.split("@")[0] || "Creator";
  if (encoded && request.headers.get("oai-authenticated-user-full-name-encoding") === "percent-encoded-utf-8") { try { name = decodeURIComponent(encoded); } catch {} }
  return { id, name: name.slice(0, 40) };
}
export function requireShortsViewer(request: Request) { const viewer = shortsViewer(request); return viewer || Response.json({ error: "Sign in to upload, like, subscribe, or comment." }, { status: 401 }); }
