# NexadortPRO · Game AI + Hard Arcade

An installable English Chrome app for Brawl Stars, Fortnite and Roblox Studio, featuring the NexadortPRO panda mascot.

## Main files

- `app/page.tsx`: navigation, three topic chats, voice controls, profile, NexadortCoin Shop and ten playable canvas missions.
- `app/globals.css`: responsive turquoise-green theme and all mascot, shop, profile and game styling.
- `app/api/chat/route.ts`: demo answers, topic checks and optional OpenAI connection.
- `public/panda-standing-closed.jpg` and `public/panda-standing-open.jpg`: generated full-body mascot frames.
- `app/layout.tsx`: English metadata.

## Features

The app includes ten harder canvas games with rendered 3D human characters:

- Crystal Clash is a top-down action game with auto-fire, chasing drones and gem drops.
- Storm Frontier has a moving, shrinking safe zone and loot collection.
- Rooftop Obby is a longer side-scrolling platformer with gravity, jumping, checkpoints and a finish portal.
- Shadow Escape is a top-down stealth mission with guards, access cards and a locked exit.
- City Sprint is an endless-runner challenge with obstacles and energy tokens.
- Stadium Rush is a sports mission with defenders and repeat scoring runs.
- Neon Velocity is a high-speed lane racing challenge.
- Summit Rescue is a mountain search-and-rescue mission.
- Coastal Guardian is an ocean rescue mission with currents and moving hazards.
- Final Save is a fast goalkeeper challenge.

A completed run awards 3–30 gold NexadortCoins, with a 100-coin daily limit. Missions last 90–135 seconds. Unlocks have fixed prices between 180 and 980 NexadortCoins, so they require repeated successful missions. There are no random prizes and no paid purchases.

The shop contains 25 generated 3D character images instead of emoji. Purchased profile pictures use the same artwork everywhere. Equipped game items also appear in the game HUD and on the player character. Every brawler, skin and outfit has a real gameplay perk such as faster auto-fire, extra health, slower storm damage or a double jump.

The profile defaults to NexadortPRO and supports an 18-character display name, unlocked profile pictures and a custom image upload up to 2 MB. Progress, NexadortCoins, owned items and the custom picture are stored in browser local storage on the current device.

The app includes a web manifest, service worker and Chrome install button, so it can be added to the home screen or desktop as a standalone PWA. A YouTube button opens the official NexadortPRO channel.

## AI and voice

Without `OPENAI_API_KEY`, the app runs in Smart Guide mode. Its local intent matcher answers common questions about brawler choice, aiming, team roles, Fortnite building, controller settings, rotations and several Roblox Studio scripting topics. With a server-side key, `/api/chat` uses the OpenAI Responses API and structured output to keep each chat on its selected game topic. `OPENAI_MODEL` is optional and defaults to `gpt-4.1-mini`. Never put API keys in client code or in `public/`.

Voice typing uses the browser SpeechRecognition API with English input. Reading answers uses speechSynthesis. Availability depends on the browser and device. The panda swaps between closed-mouth and open-mouth frames while speech playback is active.

The app also tracks best scores and wins across all ten modes, games played, total score, a permanent Career Level, collection size, daily progress goals and seven achievements. The site is an unofficial fan project. Before public access, add server-side accounts, durable progress, rate limits and an API budget. Local browser progress is suitable for this private version but can be reset or edited by the device owner.
